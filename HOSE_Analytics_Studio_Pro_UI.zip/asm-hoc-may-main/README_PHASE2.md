# HOSE Analytics Premium — ASM Phase 2

## Windows quick start (CMD)
```bat
python -m venv .venv
.venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

## Điều hướng
Thanh công cụ ngang gồm TỔNG QUAN, DỮ LIỆU, CHẤT LƯỢNG, PHÂN TÍCH, PHÂN CỤM, HỒ SƠ, GIAI ĐOẠN 2. Nhãn in đậm, không dùng icon; trên màn hình hẹp thanh điều hướng cuộn ngang.

## Giai đoạn 2
Mở `GIAI ĐOẠN 2`:
1. Upload dữ liệu bổ sung CSV/XLSX (Date, Ticker, Open, High, Low, Close, Volume) nếu có.
2. Chọn Hồi quy hoặc Phân loại.
3. Bấm HUẤN LUYỆN VÀ ĐÁNH GIÁ. Có thể bỏ chọn GridSearchCV nếu muốn chạy nhanh trước.
4. Xem bảng so sánh Train/Test, biểu đồ, Feature Importance và 20 ngày test cuối.
5. Dùng DỰ BÁO VỚI MÔ HÌNH ĐÃ HUẤN LUYỆN để dự báo phiên kế tiếp cho mã được chọn.

## Notebook
Mở `notebooks/ASM2_supervised_learning.ipynb` từ thư mục gốc dự án. Notebook dùng dữ liệu Processed đang có và chạy cả hai bài toán.

## Quan trọng về nguồn dữ liệu
Dữ liệu đang đóng gói là CafeF, không phải Vietstock. Bản kiểm thử 20 ngày là holdout từ lịch sử hiện có, không được gọi là 20 phiên Vietstock. Nạp tệp Vietstock để đáp ứng chính xác yêu cầu nguồn của giảng viên.
