from __future__ import annotations
from html import escape
import streamlit as st
def apply_dashboard_style() -> None:
 st.markdown("""
 <style>
 :root{--navy:#0b1f35;--blue:#245b9e;--teal:#0d9488;--ink:#172b42;--muted:#66788d;--line:#e3eaf2;--canvas:#f3f6fa}
 html,body,[class*="css"]{font-family:Inter,"Segoe UI",sans-serif}
 [data-testid="stAppViewContainer"]{background:var(--canvas);color:var(--ink)}
 [data-testid="stHeader"]{background:rgba(243,246,250,.94)}
 [data-testid="stSidebar"]{background:linear-gradient(180deg,#0b1f35,#153b5b);border-right:1px solid #24435e}
 [data-testid="stSidebar"] *{color:#eef5fc}
 [data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p{color:#b9cadd}
 [data-testid="stSidebarNav"]{padding:.8rem .4rem}
 [data-testid="stSidebarNav"] a{border-radius:10px;margin:.12rem 0}
 [data-testid="stSidebarNav"] a[aria-current="page"]{background:rgba(45,180,173,.2);border:1px solid rgba(119,225,215,.25)}
 .block-container{max-width:1500px;padding-top:1.5rem;padding-bottom:3rem}
 h1,h2,h3{color:var(--ink);letter-spacing:-.025em}
 h1{font-weight:780}
 [data-testid="stMetric"]{background:#fff;border:1px solid var(--line);padding:1rem 1.1rem;border-radius:16px;box-shadow:0 5px 20px rgba(16,38,63,.045);min-height:105px}
 [data-testid="stMetricLabel"] p{color:var(--muted);font-size:.82rem;font-weight:650}
 [data-testid="stMetricValue"]{color:var(--navy);font-size:1.65rem;font-weight:760}
 [data-testid="stVerticalBlockBorderWrapper"]{background:#fff;border:1px solid var(--line);border-radius:16px;box-shadow:0 4px 16px rgba(16,38,63,.035)}
 [data-testid="stDataFrame"]{border:1px solid var(--line);border-radius:12px;overflow:hidden}
 [data-testid="stAlert"]{border-radius:12px}
 [data-testid="stTabs"] button[role="tab"]{font-weight:650}
 .stButton>button,.stDownloadButton>button{border-radius:10px;font-weight:680;min-height:2.65rem}
 .stButton>button[kind="primary"]{background:linear-gradient(110deg,#126b78,#0d9488);border-color:#0d9488}
 [data-testid="stExpander"]{border:1px solid var(--line);border-radius:12px;background:#fff}
 .brand{display:flex;gap:12px;align-items:center;padding:.7rem .1rem 1rem;border-bottom:1px solid #ffffff20;margin-bottom:1rem}
 .brand-icon{display:grid;place-items:center;width:44px;height:44px;border-radius:13px;background:#ffffff18;font-size:23px}
 .brand-name{font-size:1rem;font-weight:800;color:white}.brand-sub{font-size:.74rem;color:#b9cadd}
 .hero{background:linear-gradient(112deg,#0b1f35 0%,#17466b 65%,#087f83 120%);border-radius:20px;padding:1.65rem 1.8rem;margin-bottom:1.25rem;box-shadow:0 14px 34px #0b1f3522;position:relative;overflow:hidden}
 .hero:after{content:"";position:absolute;width:260px;height:260px;border:1px solid #ffffff18;border-radius:50%;right:-65px;top:-130px;box-shadow:0 0 0 28px #ffffff08,0 0 0 58px #ffffff06}
 .hero-kicker{color:#8ee3d9;font-size:.72rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase}
 .hero h1{color:white;font-size:clamp(1.7rem,3vw,2.35rem);margin:.35rem 0 .5rem;line-height:1.15}
 .hero p{color:#d4e3ef;margin:0;max-width:900px;line-height:1.6}
 .section-kicker{color:#0d827e;font-size:.72rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;margin:.35rem 0 .2rem}
 .muted{color:var(--muted);font-size:.88rem}
 .ticker{display:inline-block;background:#edf4fb;color:#1d4d7b;border:1px solid #dce8f4;border-radius:8px;padding:.3rem .55rem;margin:.15rem;font-weight:700;font-size:.82rem}
 @media(max-width:760px){.block-container{padding:1rem}.hero{padding:1.2rem;border-radius:15px}}
 </style>""",unsafe_allow_html=True)
def render_page_header(section:str,title:str,description:str)->None:
 st.markdown(f'<section class="hero"><div class="hero-kicker">{escape(section)}</div><h1>{escape(title)}</h1><p>{escape(description)}</p></section>',unsafe_allow_html=True)
def render_section_heading(title:str,caption:str|None=None)->None:
 st.markdown(f'<div class="section-kicker">{escape(title)}</div>',unsafe_allow_html=True)
 if caption: st.caption(caption)
def render_empty_panel(title:str,description:str)->None:
 with st.container(border=True):
  st.markdown(f"**{escape(title)}**")
  st.caption(description)
