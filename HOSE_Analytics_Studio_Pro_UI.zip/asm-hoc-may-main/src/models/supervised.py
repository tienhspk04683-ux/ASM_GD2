"""Leakage-aware supervised experiments for next-session close and direction."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.base import clone
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.neighbors import KNeighborsRegressor, KNeighborsClassifier
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import (mean_absolute_error, mean_squared_error, r2_score,
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    confusion_matrix, classification_report)
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit
from sklearn.inspection import permutation_importance
import joblib

ROOT=Path(__file__).resolve().parents[2]
MODEL_DIR=ROOT/"artifacts"/"supervised"
NUMERIC=["Open_Ratio","High_Ratio","Low_Ratio","Volume_Log","Return_1","Return_2","Return_5","MA5_Ratio","MA20_Ratio","Volatility_5","Volatility_20","Range_Ratio"]
CATEGORICAL=["Ticker"]
FEATURES=NUMERIC+CATEGORICAL

def make_supervised_frame(raw:pd.DataFrame, require_target:bool=True)->pd.DataFrame:
    d=raw.copy(); d["Date"]=pd.to_datetime(d["Date"],errors="coerce")
    d["Ticker"]=d["Ticker"].astype(str).str.upper().str.strip()
    for c in ["Open","High","Low","Close","Volume"]: d[c]=pd.to_numeric(d[c],errors="coerce")
    d=d.dropna(subset=["Date","Ticker","Open","High","Low","Close","Volume"])
    d=d.sort_values(["Ticker","Date"]).drop_duplicates(["Ticker","Date"],keep="last")
    g=d.groupby("Ticker",group_keys=False)
    d["Return_1"]=g["Close"].pct_change()
    d["Return_2"]=g["Close"].pct_change(2)
    d["Return_5"]=g["Close"].pct_change(5)
    d["MA5"]=g["Close"].transform(lambda s:s.rolling(5,min_periods=5).mean())
    d["MA20"]=g["Close"].transform(lambda s:s.rolling(20,min_periods=20).mean())
    d["Volatility_5"]=g["Return_1"].transform(lambda s:s.rolling(5,min_periods=5).std())
    d["Volatility_20"]=g["Return_1"].transform(lambda s:s.rolling(20,min_periods=20).std())
    d["Open_Ratio"]=d["Open"]/d["Close"]
    d["High_Ratio"]=d["High"]/d["Close"]
    d["Low_Ratio"]=d["Low"]/d["Close"]
    d["Volume_Log"]=np.log1p(d["Volume"].clip(lower=0))
    d["MA5_Ratio"]=d["MA5"]/d["Close"]
    d["MA20_Ratio"]=d["MA20"]/d["Close"]
    d["Range_Ratio"]=(d["High"]-d["Low"])/d["Close"]
    d["Target_Next_Close"]=g["Close"].shift(-1)
    d["Target_Next_Date"]=g["Date"].shift(-1)
    d["Target_Next_Return"]=d["Target_Next_Close"]/d["Close"]-1
    d["Target_Direction"]=(d["Target_Next_Return"]>0).astype("int8")
    d=d.replace([np.inf,-np.inf],np.nan)
    required=NUMERIC + (["Target_Next_Close","Target_Next_Date","Target_Next_Return"] if require_target else [])
    d=d.dropna(subset=required)
    return d.sort_values(["Date","Ticker"]).reset_index(drop=True)

def _preprocessor():
    num=Pipeline([("imputer",SimpleImputer(strategy="median")),("scale",StandardScaler())])
    cat=Pipeline([("imputer",SimpleImputer(strategy="most_frequent")),("onehot",OneHotEncoder(handle_unknown="ignore"))])
    return ColumnTransformer([("num",num,NUMERIC),("ticker",cat,CATEGORICAL)])

def _time_split(df,test_fraction=.2):
    dates=np.array(sorted(df["Date"].unique()))
    if len(dates)<30: raise ValueError("Cần tối thiểu 30 ngày giao dịch để chia train/test theo thời gian.")
    cut=max(1,int(len(dates)*(1-test_fraction)))
    cutoff=pd.Timestamp(dates[cut])
    train=df[df.Date<cutoff].copy(); test=df[df.Date>=cutoff].copy()
    if train.empty or test.empty: raise ValueError("Không tạo được tập train/test theo thời gian.")
    return train,test,cutoff

def _reg_models():
    return {"Linear Regression":LinearRegression(),"KNN Regressor":KNeighborsRegressor(n_neighbors=9,weights="distance",n_jobs=-1),"Decision Tree":DecisionTreeRegressor(max_depth=5,min_samples_leaf=5,random_state=42),"Random Forest":RandomForestRegressor(n_estimators=120,max_depth=8,min_samples_leaf=8,n_jobs=2,random_state=42)}
def _clf_models():
    return {"Logistic Regression":LogisticRegression(max_iter=2000,class_weight="balanced"),"KNN Classifier":KNeighborsClassifier(n_neighbors=9,weights="distance",n_jobs=-1),"Decision Tree":DecisionTreeClassifier(max_depth=5,min_samples_leaf=5,class_weight="balanced",random_state=42),"Random Forest":RandomForestClassifier(n_estimators=300,max_depth=10,min_samples_leaf=3,class_weight="balanced_subsample",n_jobs=-1,random_state=42)}

def _fit_task(df,task):
    train,test,cutoff=_time_split(df)
    ycol="Target_Next_Close" if task=="regression" else "Target_Direction"
    models=_reg_models() if task=="regression" else _clf_models()
    rows=[]; fitted={}; predictions=[]
    for name,est in models.items():
        # KNN on a bounded deterministic training sample and numeric features only:
        # keeps inference responsive on ~50k panel rows while preserving chronological holdout.
        if name.startswith("KNN"):
            pipe=Pipeline([("prep",Pipeline([("imputer",SimpleImputer(strategy="median")),("scale",StandardScaler())])),("model",est)])
            sample=train.sample(n=min(2500,len(train)),random_state=42).sort_values(["Date","Ticker"])
            Xtr=sample[NUMERIC]; ytr=sample[ycol]; Xte=test[NUMERIC]; yte=test[ycol]
            pipe.fit(Xtr,ytr); ptest=pipe.predict(Xte)
            # KNN train score is estimated with expanding date-blocked CV, not resubstitution
            # (which would trivially return each observation as its own nearest neighbor).
            from sklearn.model_selection import TimeSeriesSplit
            cv_true=[]; cv_pred=[]
            split_dates=np.array(sorted(sample.Date.unique()))
            for tri,vai in TimeSeriesSplit(n_splits=3).split(split_dates):
                trd=set(split_dates[tri]); vad=set(split_dates[vai])
                trmask=sample.Date.isin(trd).to_numpy(); vamask=sample.Date.isin(vad).to_numpy()
                if trmask.sum() and vamask.sum():
                    fold=clone(pipe); fold.fit(Xtr.loc[trmask],ytr.loc[trmask])
                    cv_true.extend(ytr.loc[vamask].tolist()); cv_pred.extend(fold.predict(Xtr.loc[vamask]).tolist())
            ytr_eval=np.asarray(cv_true); ptrain=np.asarray(cv_pred)
        else:
            pipe=Pipeline([("prep",_preprocessor()),("model",est)])
            Xtr=train[FEATURES]; Xte=test[FEATURES]; ytr=train[ycol]; yte=test[ycol]
            pipe.fit(Xtr,ytr); ptrain=pipe.predict(Xtr); ptest=pipe.predict(Xte); ytr_eval=ytr
        if task=="regression":
            trm=mean_squared_error(ytr_eval,ptrain)**.5; tem=mean_squared_error(yte,ptest)**.5
            row={"Model":name,"Train_MAE":mean_absolute_error(ytr_eval,ptrain),"Test_MAE":mean_absolute_error(yte,ptest),"Train_RMSE":trm,"Test_RMSE":tem,"Train_R2":r2_score(ytr_eval,ptrain),"Test_R2":r2_score(yte,ptest),"Generalization_Gap_RMSE":tem-trm}
        else:
            prob=pipe.predict_proba(Xte)[:,1] if hasattr(pipe,"predict_proba") else None
            train_acc=accuracy_score(ytr_eval,ptrain); train_f1=f1_score(ytr_eval,ptrain,zero_division=0)
            row={"Model":name,"Train_Accuracy":train_acc,"Test_Accuracy":accuracy_score(yte,ptest),"Train_F1":train_f1,"Test_Precision":precision_score(yte,ptest,zero_division=0),"Test_Recall":recall_score(yte,ptest,zero_division=0),"Test_F1":f1_score(yte,ptest,zero_division=0),"Test_ROC_AUC":roc_auc_score(yte,prob) if prob is not None and yte.nunique()==2 else np.nan,"Generalization_Gap_F1":train_f1-f1_score(yte,ptest,zero_division=0)}
        rows.append(row); fitted[name]=pipe
        pred=test[["Date","Target_Next_Date","Ticker",ycol]].copy(); pred["Model"]=name; pred["Prediction"]=ptest
        if task=="classification" and hasattr(pipe,"predict_proba"): pred["Probability_Up"]=pipe.predict_proba(Xte)[:,1]
        predictions.append(pred)
    metrics=pd.DataFrame(rows)
    rankcol="Test_RMSE" if task=="regression" else "Test_F1"
    best_name=metrics.sort_values(rankcol,ascending=(task=="regression")).iloc[0]["Model"]
    return train,test,cutoff,metrics,fitted,best_name,pd.concat(predictions,ignore_index=True)

def run_experiments(raw:pd.DataFrame,task:str,tune:bool=True):
    if task not in {"regression","classification"}: raise ValueError("task phải là regression hoặc classification")
    frame=make_supervised_frame(raw)
    train,test,cutoff,metrics,fitted,best_name,preds=_fit_task(frame,task)
    tune_result=None
    # Tune only RF and KNN on chronological folds of training partition.
    if tune:
        base=_reg_models()["Random Forest"] if task=="regression" else _clf_models()["Random Forest"]
        pipe=Pipeline([("prep",_preprocessor()),("model",base)])
        grid={"model__n_estimators":[80,120],"model__max_depth":[5,8],"model__min_samples_leaf":[8]}
        # Date-blocked expanding folds: all tickers from a calendar date stay in one fold.
        unique_dates=np.array(sorted(train.Date.unique()))
        fold_edges=np.linspace(max(20, int(len(unique_dates)*0.45)), len(unique_dates), 4, dtype=int)
        cv_splits=[]
        for j in range(3):
            val_start=fold_edges[j]
            val_end=fold_edges[j+1]
            if val_end<=val_start or val_start<1: continue
            tr_dates=set(unique_dates[:val_start]); va_dates=set(unique_dates[val_start:val_end])
            tr_idx=np.flatnonzero(train.Date.isin(tr_dates).to_numpy())
            va_idx=np.flatnonzero(train.Date.isin(va_dates).to_numpy())
            if len(tr_idx) and len(va_idx): cv_splits.append((tr_idx,va_idx))
        if not cv_splits: raise ValueError("Không đủ ngày để tạo các fold validation theo thời gian.")
        ycol="Target_Next_Close" if task=="regression" else "Target_Direction"
        scoring="neg_root_mean_squared_error" if task=="regression" else "f1"
        search=GridSearchCV(pipe,grid,cv=cv_splits,scoring=scoring,n_jobs=2,refit=True)
        search.fit(train[FEATURES],train[ycol])
        tuned=search.best_estimator_; yp=tuned.predict(test[FEATURES]); y=test[ycol]
        ytrain=train[ycol]; ytrain_pred=tuned.predict(train[FEATURES])
        if task=="regression": tuned_row={"Model":"Random Forest (tuned)","Train_MAE":mean_absolute_error(ytrain,ytrain_pred),"Test_MAE":mean_absolute_error(y,yp),"Train_RMSE":mean_squared_error(ytrain,ytrain_pred)**.5,"Test_RMSE":mean_squared_error(y,yp)**.5,"Train_R2":r2_score(ytrain,ytrain_pred),"Test_R2":r2_score(y,yp),"Generalization_Gap_RMSE":mean_squared_error(y,yp)**.5-mean_squared_error(ytrain,ytrain_pred)**.5,"Best_Params":json.dumps(search.best_params_)}
        else:
            pr=tuned.predict_proba(test[FEATURES])[:,1]
            train_f1=f1_score(ytrain,ytrain_pred,zero_division=0)
            tuned_row={"Model":"Random Forest (tuned)","Train_Accuracy":accuracy_score(ytrain,ytrain_pred),"Test_Accuracy":accuracy_score(y,yp),"Train_F1":train_f1,"Test_Precision":precision_score(y,yp,zero_division=0),"Test_Recall":recall_score(y,yp,zero_division=0),"Test_F1":f1_score(y,yp,zero_division=0),"Test_ROC_AUC":roc_auc_score(y,pr) if y.nunique()==2 else np.nan,"Generalization_Gap_F1":train_f1-f1_score(y,yp,zero_division=0),"Best_Params":json.dumps(search.best_params_)}
        metrics=pd.concat([metrics,pd.DataFrame([tuned_row])],ignore_index=True)
        tuned_pred=test[["Date","Target_Next_Date","Ticker",ycol]].copy(); tuned_pred["Model"]="Random Forest (tuned)"; tuned_pred["Prediction"]=yp
        if task=="classification": tuned_pred["Probability_Up"]=tuned.predict_proba(test[FEATURES])[:,1]
        preds=pd.concat([preds,tuned_pred],ignore_index=True)
        fitted["Random Forest (tuned)"]=tuned
        tune_result={"best_params":search.best_params_,"best_cv_score":float(search.best_score_)}
        rankcol="Test_RMSE" if task=="regression" else "Test_F1"
        best_name=metrics.sort_values(rankcol,ascending=(task=="regression")).iloc[0]["Model"]
    best=fitted[best_name]
    # Always expose Random Forest importance, even when another model wins the test metric.
    importance_model=fitted.get("Random Forest (tuned)",fitted.get("Random Forest",best))
    model=importance_model.named_steps["model"]
    importance=None
    if hasattr(model,"feature_importances_"):
        prep=importance_model.named_steps["prep"]
        names=prep.get_feature_names_out()
        importance=pd.DataFrame({"Feature":names,"Importance":model.feature_importances_}).sort_values("Importance",ascending=False)
    MODEL_DIR.mkdir(parents=True,exist_ok=True)
    joblib.dump(best,MODEL_DIR/f"{task}_best.joblib")
    metrics.to_csv(MODEL_DIR/f"{task}_metrics.csv",index=False,encoding="utf-8-sig")
    preds.to_csv(MODEL_DIR/f"{task}_predictions.csv",index=False,encoding="utf-8-sig")
    if importance is not None: importance.to_csv(MODEL_DIR/f"{task}_feature_importance.csv",index=False,encoding="utf-8-sig")
    meta={"task":task,"best_model":best_name,"train_rows":len(train),"test_rows":len(test),"test_start":str(cutoff.date()),"features":FEATURES,"tuning":tune_result,"source_note":"Current checked-in history is CafeF, not Vietstock. Verify price basis/corporate actions before financial interpretation."}
    (MODEL_DIR/f"{task}_metadata.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding="utf-8")
    return {"frame":frame,"train":train,"test":test,"cutoff":cutoff,"metrics":metrics,"models":fitted,"best_name":best_name,"best_model":best,"predictions":preds,"importance":importance,"metadata":meta,"tuning":tune_result}

def predict_new_rows(raw:pd.DataFrame,task:str):
    path=MODEL_DIR/f"{task}_best.joblib"
    if not path.exists(): raise FileNotFoundError(f"Chưa có mô hình {task}; hãy huấn luyện trước.")
    frame=make_supervised_frame(raw, require_target=False)
    model=joblib.load(path)
    out=frame[["Date","Ticker"]+FEATURES].copy()
    out["Prediction"]=model.predict(frame[FEATURES])
    if task=="classification" and hasattr(model,"predict_proba"): out["Probability_Up"]=model.predict_proba(frame[FEATURES])[:,1]
    return out
