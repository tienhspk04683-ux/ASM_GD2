import json
from pathlib import Path
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import colorsys
import hashlib
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import RobustScaler,StandardScaler
from src.dashboard_ui import render_page_header,render_empty_panel,render_section_heading
from src.data.research import PROJECT_ROOT, load_processed, known_ohlc_flags
from src.features.risk_features import build_conditional_features
from src.models.clustering import run_clustering
from src.models.clustering import FEATURE_SETS
ART=PROJECT_ROOT/"artifacts"/"clustering"
FP=ART/"features_conditional.csv"; LP=ART/"clustering_labels.csv"; PP=ART/"cluster_profiles.csv"
render_page_header("CLUSTER INTELLIGENCE / COMPANY PROFILE","Hồ sơ doanh nghiệp","Tra cứu nhãn cụm theo cấu hình, so sánh đặc trưng và quan sát bản đồ PCA.")
st.warning("Cluster ID là nhãn kỹ thuật, không phải mức rủi ro. Các đặc trưng dựa trên Close CafeF chưa xác minh price basis/Corporate Actions.")
if not all(p.exists() for p in [FP,LP,PP]):
    render_empty_panel("Chưa có kết quả phân cụm","Hãy nạp dữ liệu Processed và chạy thí nghiệm tại trang Phân cụm mô hình."); st.stop()
features=pd.read_csv(FP); labels=pd.read_csv(LP); profiles=pd.read_csv(PP)
# When user has staged additional tickers/dates, rebuild the feature matrix and clustering labels
# from the merged dataset so newly added symbols appear without editing the original CSV.
staged_path=PROJECT_ROOT/"data"/"staging"/"additional_stock_data.csv"
if staged_path.exists():
    live_source=load_processed()
    live_features, _, _ = build_conditional_features(live_source, known_ohlc_flags(live_source))
    live_run=run_clustering(live_features, random_state=42)
    features=live_features
    labels=live_run.labels
    profiles=live_run.profiles
configs=labels[["Feature_Set","Algorithm","Scaler","Parameters"]].drop_duplicates().reset_index(drop=True)
configs["label"]=configs.apply(lambda r:f"{r.Algorithm} · {r.Feature_Set} · {r.Scaler} · {r.Parameters}",axis=1)
choice=st.selectbox("Cấu hình phân cụm",configs.label.tolist())
cfg=configs.loc[configs.label.eq(choice)].iloc[0]
mask=(labels.Feature_Set.eq(cfg.Feature_Set)&labels.Algorithm.eq(cfg.Algorithm)&labels.Scaler.eq(cfg.Scaler)&labels.Parameters.eq(cfg.Parameters))
labs=labels.loc[mask,["Ticker","Cluster"]].copy()
prof=profiles.loc[profiles.Feature_Set.eq(cfg.Feature_Set)&profiles.Algorithm.eq(cfg.Algorithm)&profiles.Scaler.eq(cfg.Scaler)&profiles.Parameters.eq(cfg.Parameters)].copy()
a,b,c=st.columns(3)
a.metric("Doanh nghiệp",len(labs)); b.metric("Số cụm (không tính noise)",labs.loc[labs.Cluster.ne(-1),"Cluster"].nunique()); c.metric("Noise DBSCAN",int(labs.Cluster.eq(-1).sum()))
left,right=st.columns([1,1],gap="large")
with left:
    render_section_heading("Quy mô từng cụm")
    counts=labs.assign(Cụm=labs.Cluster.map(lambda x:"Noise (-1)" if x==-1 else f"Cụm {x}")).groupby("Cụm").size().reset_index(name="Số mã")
    fig=px.bar(counts,x="Cụm",y="Số mã",color="Cụm",color_discrete_sequence=["#176b87","#0d9488","#8aa7c4","#c49a5a"])
    fig.update_layout(height=320,showlegend=False,paper_bgcolor="white",plot_bgcolor="white")
    st.plotly_chart(fig,use_container_width=True)
with right:
    render_section_heading("Hồ sơ đặc trưng theo cụm")
    st.dataframe(prof.drop(columns=["Tickers"],errors="ignore"),hide_index=True,use_container_width=True)
render_section_heading("Bản đồ PCA 2D","PCA chỉ giảm chiều để trực quan hóa; không phải trục rủi ro.")
feature_cols=FEATURE_SETS[cfg.Feature_Set]
scaler=StandardScaler() if cfg.Scaler=="StandardScaler" else RobustScaler()
X=scaler.fit_transform(features[feature_cols])
coords=PCA(n_components=2,random_state=42).fit_transform(X)
plot=labs.merge(features[["Ticker"]],on="Ticker",how="left")
plot["PC1"]=coords[:,0];plot["PC2"]=coords[:,1]
plot["Cụm"]=plot.Cluster.map(lambda x:"Noise (-1)" if x==-1 else f"Cụm {x}")
# Each ticker gets a deterministic, unique HSL color; cluster membership is shown by a circular envelope.
plot=plot.reset_index(drop=True)
def ticker_color(ticker, used):
    # Stable hash-derived hue; collision resolution guarantees distinct RGB values in this chart.
    base=int(hashlib.sha256(ticker.encode("utf-8")).hexdigest()[:8],16)/0xFFFFFFFF
    for step in range(360):
        hue=(base+step*0.618033988749895)%1.0
        r,g,b=colorsys.hsv_to_rgb(hue,0.76,0.82)
        color=f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        if color not in used:
            used.add(color); return color
    raise RuntimeError("Không tạo được màu riêng cho mã cổ phiếu.")
_used_colors=set()
plot["Point_Color"]=[ticker_color(t,_used_colors) for t in plot["Ticker"].astype(str)]
fig=go.Figure()
cluster_palette={-1:"#596579",0:"#0d9488",1:"#2563eb",2:"#d97706",3:"#9333ea",4:"#db2777",5:"#0891b2"}
for cluster, group in plot.groupby("Cluster"):
    if int(cluster) != -1 and len(group)>=2:
        cx,cy=group.PC1.mean(),group.PC2.mean()
        radius=max(float(np.sqrt((group.PC1-cx)**2+(group.PC2-cy)**2).max())*1.12,0.08)
        theta=np.linspace(0,2*np.pi,120)
        fig.add_trace(go.Scatter(x=cx+radius*np.cos(theta),y=cy+radius*np.sin(theta),mode="lines",line=dict(color=cluster_palette.get(int(cluster),"#64748b"),width=2,dash="dash"),fill="toself",fillcolor=cluster_palette.get(int(cluster),"#64748b"),opacity=.10,name=f"Vùng bao cụm {cluster}",hoverinfo="skip"))
for _,r in plot.iterrows():
    fig.add_trace(go.Scatter(x=[r.PC1],y=[r.PC2],mode="markers+text",text=[r.Ticker],textposition="top center",name=r.Ticker,legendgroup=r.Ticker,marker=dict(size=13,color=r.Point_Color,line=dict(color="white",width=1.2)),customdata=[[int(r.Cluster),r.Ticker]],hovertemplate="Mã: %{customdata[1]}<br>Cụm: %{customdata[0]}<extra></extra>"))
for cluster, group in plot.groupby("Cluster"):
    fig.add_trace(go.Scatter(x=[group.PC1.mean()],y=[group.PC2.mean()],mode="markers",marker=dict(symbol="x",size=15,color=cluster_palette.get(int(cluster),"#64748b"),line=dict(width=2)),name=f"Tâm cụm {cluster}"))
fig.update_layout(height=650,paper_bgcolor="white",plot_bgcolor="white",xaxis_title="Thành phần chính PC1",yaxis_title="Thành phần chính PC2",legend_title="Mã / vùng cụm",margin=dict(l=10,r=10,t=20,b=10))
fig.update_yaxes(scaleanchor="x",scaleratio=1)
st.plotly_chart(fig,use_container_width=True)
st.caption("Mỗi mã có màu điểm riêng biệt. Vòng tròn nét đứt là vùng bao trực quan quanh các điểm cùng cụm trong mặt phẳng PCA; không phải ranh giới phân loại hay mức rủi ro tuyệt đối.")
render_section_heading("Tra cứu doanh nghiệp")
ticker=st.selectbox("Chọn mã",sorted(features.Ticker.astype(str).unique()))
row=features.loc[features.Ticker.astype(str).eq(ticker)].iloc[0]
lab=labs.loc[labs.Ticker.astype(str).eq(ticker),"Cluster"]
c1,c2=st.columns([1,2])
c1.metric("Nhãn cụm",str(int(lab.iloc[0])) if len(lab) else "Chưa có")
c2.dataframe(pd.DataFrame({"Đặc trưng":row.index,"Giá trị":row.values}),hide_index=True,use_container_width=True)
members=labs.loc[labs.Cluster.eq(int(lab.iloc[0])),"Ticker"].astype(str).tolist() if len(lab) else []
st.caption("Doanh nghiệp cùng nhãn kỹ thuật: "+", ".join(members))
st.download_button("Tải hồ sơ doanh nghiệp CSV",features.to_csv(index=False).encode("utf-8-sig"),"company_features.csv","text/csv")
