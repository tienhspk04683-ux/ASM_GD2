from pathlib import Path
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import seaborn as sns
import matplotlib.pyplot as plt
from src.dashboard_ui import render_page_header,render_section_heading,render_empty_panel
from src.data.research import load_processed,known_ohlc_flags,PROJECT_ROOT
from src.features.risk_features import build_conditional_features

render_page_header("RESEARCH / EXPLORATORY DATA ANALYSIS","Phân tích dữ liệu","Khám phá giá, khối lượng, phân phối lợi suất và cấu trúc tương quan trước khi phân cụm.")
try:
    df=load_processed()
except (FileNotFoundError,ValueError,OSError) as exc:
    render_empty_panel("Chưa có dữ liệu để phân tích",str(exc)); st.stop()
df["Date"]=pd.to_datetime(df["Date"],errors="coerce")
tickers=sorted(df.Ticker.dropna().astype(str).unique())
c1,c2=st.columns([1,2])
ticker=c1.selectbox("Chọn mã cổ phiếu",tickers,index=0)
period=c2.selectbox("Khoảng hiển thị",["Toàn bộ dữ liệu","1 năm gần nhất","6 tháng gần nhất"])
view=df[df.Ticker.astype(str).eq(ticker)].sort_values("Date").copy()
if period!="Toàn bộ dữ liệu" and view.Date.notna().any():
    days=365 if period.startswith("1") else 183
    view=view[view.Date>=view.Date.max()-pd.Timedelta(days=days)]
tabs=st.tabs(["Giá & khối lượng","Phân phối lợi suất","Tương quan","Đặc trưng rủi ro"])
with tabs[0]:
    render_section_heading(f"{ticker} · Giá đóng cửa","Giá Close theo dữ liệu nguồn; chưa hiệu chỉnh Corporate Actions.")
    fig=go.Figure()
    fig.add_trace(go.Scatter(x=view.Date,y=view.Close,mode="lines",name="Close",line=dict(color="#176b87",width=2)))
    fig.update_layout(height=390,hovermode="x unified",paper_bgcolor="white",plot_bgcolor="white",margin=dict(l=10,r=10,t=20,b=10),xaxis_title="",yaxis_title="Close")
    st.plotly_chart(fig,use_container_width=True)
    vol=go.Figure(go.Bar(x=view.Date,y=view.Volume,name="Volume",marker_color="#6aa6a1"))
    vol.update_layout(height=260,paper_bgcolor="white",plot_bgcolor="white",margin=dict(l=10,r=10,t=15,b=10),xaxis_title="",yaxis_title="Volume")
    st.plotly_chart(vol,use_container_width=True)
    st.dataframe(view[["Date","Open","High","Low","Close","Volume"]].tail(20),hide_index=True,use_container_width=True)
with tabs[1]:
    view["Return"]=pd.to_numeric(view.Close,errors="coerce").pct_change()
    r=view.Return.replace([np.inf,-np.inf],np.nan).dropna()
    m1,m2,m3=st.columns(3)
    m1.metric("Số return hợp lệ",f"{len(r):,}")
    m2.metric("Return trung bình",f"{r.mean():.4%}" if len(r) else "—")
    m3.metric("Độ lệch chuẩn",f"{r.std():.4%}" if len(r)>1 else "—")
    if len(r):
        fig=px.histogram(r,x="Return",nbins=45,marginal="box",color_discrete_sequence=["#277c91"],labels={"Return":"Simple Return"})
        fig.update_layout(height=370,paper_bgcolor="white",plot_bgcolor="white",showlegend=False)
        st.plotly_chart(fig,use_container_width=True)
        st.caption("Return mô tả thay đổi Close giữa hai dòng quan sát liên tiếp; cần thận trọng khi có ngày vắng hoặc corporate actions.")
    else: st.warning("Không đủ quan sát để tạo phân phối Return.")
with tabs[2]:
    numeric=view[["Open","High","Low","Close","Volume"]].apply(pd.to_numeric,errors="coerce")
    corr=numeric.corr()
    fig=px.imshow(corr,text_auto=".2f",color_continuous_scale="RdBu_r",zmin=-1,zmax=1,aspect="auto")
    fig.update_layout(height=420,paper_bgcolor="white")
    st.plotly_chart(fig,use_container_width=True)
    st.caption("Tương quan Pearson mô tả quan hệ tuyến tính, không chứng minh quan hệ nhân quả.")
with tabs[3]:
    try:
        features,sensitivity,diag=build_conditional_features(df,known_ohlc_flags(df))
        st.metric("Số mã có thể tạo đặc trưng",len(features))
        st.dataframe(features,hide_index=True,use_container_width=True)
        st.download_button("Tải đặc trưng CSV",features.to_csv(index=False).encode("utf-8-sig"),"features_conditional.csv","text/csv")
        st.markdown("**Phân tích độ nhạy**")
        st.dataframe(sensitivity,hide_index=True,use_container_width=True)
        st.caption(f"{diag['return_rows']:,} return kề hợp lệ; {diag['gap_skipped_pairs']:,} cặp bị bỏ qua do khoảng trống.")
    except Exception as exc: st.error(f"Không thể tạo đặc trưng: {exc}")
st.caption("Biểu đồ chỉ dùng dữ liệu có trong file Processed; không nội suy và không tạo dữ liệu mẫu.")
