from __future__ import annotations
import sys
from pathlib import Path
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from sklearn.metrics import confusion_matrix
from src.dashboard_ui import render_page_header, render_section_heading
from src.data.research import load_processed, PROJECT_ROOT
from src.models.supervised import run_experiments, make_supervised_frame, predict_new_rows, MODEL_DIR

render_page_header("GIAI ĐOẠN 2 · SUPERVISED LEARNING", "Mở rộng mô hình và đánh giá dự báo", "Hai bài toán độc lập: dự báo giá đóng cửa (hồi quy) và dự báo hướng tăng/giảm (phân loại), kèm tối ưu hóa và kiểm thử theo thời gian.")
st.warning("Dữ liệu lịch sử đóng gói trong dự án hiện được xác định là CafeF, không phải Vietstock. Kết quả 20 phiên gần nhất trên đây là kiểm thử ngoài mẫu theo dữ liệu hiện có; để đáp ứng đúng yêu cầu nguồn Vietstock, cần thay/bổ sung file Vietstock xác thực. Giá Close và Corporate Actions cần được xác minh.")

# Merge user-uploaded additions without overwriting the original processed file.
try:
    raw=load_processed()
except Exception as exc:
    st.error(f"Không đọc được dữ liệu: {exc}"); st.stop()
st.subheader("1. Bổ sung dữ liệu mới")
st.caption("Tải CSV/XLSX có các cột Date, Ticker, Open, High, Low, Close, Volume. Dữ liệu được lưu riêng tại data/staging và hợp nhất theo Ticker–Date; file Processed gốc không bị ghi đè.")
upload=st.file_uploader("Thêm lịch sử giao dịch",type=["csv","xlsx"],key="phase2_upload")
if upload is not None:
    try:
        add=pd.read_csv(upload) if upload.name.lower().endswith('.csv') else pd.read_excel(upload)
        required={"Date","Ticker","Open","High","Low","Close","Volume"}
        missing=required-set(add.columns)
        if missing: st.error("Thiếu cột bắt buộc: "+", ".join(sorted(missing)))
        else:
            add["Date"]=pd.to_datetime(add["Date"],errors="coerce")
            add["Ticker"]=add["Ticker"].astype(str).str.upper().str.strip()
            for c in ["Open","High","Low","Close","Volume"]: add[c]=pd.to_numeric(add[c],errors="coerce")
            add=add.dropna(subset=list(required))
            staging=PROJECT_ROOT/"data"/"staging"; staging.mkdir(parents=True,exist_ok=True)
            dest=staging/"additional_stock_data.csv"
            if dest.exists():
                old=pd.read_csv(dest); old["Date"]=pd.to_datetime(old["Date"],errors="coerce")
                add=pd.concat([old,add],ignore_index=True)
            add=add.drop_duplicates(["Ticker","Date"],keep="last").sort_values(["Ticker","Date"])
            add.to_csv(dest,index=False,encoding="utf-8-sig")
            st.success(f"Đã lưu {len(add):,} dòng dữ liệu bổ sung. Tải lại trang để cập nhật các công cụ.")
    except Exception as exc: st.error(f"Không thể đọc file: {exc}")
staging_path=PROJECT_ROOT/"data"/"staging"/"additional_stock_data.csv"
if staging_path.exists():
    extra=pd.read_csv(staging_path); extra["Date"]=pd.to_datetime(extra["Date"],errors="coerce")
    raw=pd.concat([raw,extra],ignore_index=True).drop_duplicates(["Ticker","Date"],keep="last")
raw["Date"]=pd.to_datetime(raw["Date"],errors="coerce")
raw=raw.sort_values(["Ticker","Date"])
a,b,c=st.columns(3); a.metric("Số mã hiện có",raw.Ticker.nunique()); b.metric("Tổng bản ghi",f"{len(raw):,}"); c.metric("Ngày cuối",raw.Date.max().strftime("%d/%m/%Y"))

st.divider(); st.subheader("2. Chọn bài toán và huấn luyện")
task_label=st.radio("Bài toán",["Hồi quy · Dự báo giá đóng cửa phiên kế tiếp","Phân loại · Dự báo tăng/giảm phiên kế tiếp"],horizontal=True)
task="regression" if task_label.startswith("Hồi quy") else "classification"
tune=st.checkbox("Tối ưu siêu tham số Random Forest (GridSearchCV, chia theo thời gian)",value=True)
if st.button("HUẤN LUYỆN VÀ ĐÁNH GIÁ",type="primary",use_container_width=True):
    try:
        with st.spinner("Đang tạo đặc trưng, chia train/test theo thời gian và huấn luyện..."):
            result=run_experiments(raw,task,tune=tune)
        st.session_state[f"phase2_{task}"]=result
        st.success(f"Hoàn tất {task}. Mô hình được chọn theo chỉ số trên tập Test: {result['best_name']}.")
    except Exception as exc: st.exception(exc)

result=st.session_state.get(f"phase2_{task}")
if result is None and (MODEL_DIR/f"{task}_metrics.csv").exists():
    try:
        metrics=pd.read_csv(MODEL_DIR/f"{task}_metrics.csv")
        st.info("Đã tìm thấy kết quả lần chạy trước. Huấn luyện lại để tái tạo đầy đủ biểu đồ và kiểm thử trên dữ liệu hiện tại.")
        st.dataframe(metrics,use_container_width=True,hide_index=True)
    except Exception: pass
if result:
    metrics=result["metrics"].copy(); meta=result["metadata"]
    st.divider(); st.subheader("3. So sánh mô hình")
    st.caption(f"Train: {meta['train_rows']:,} dòng · Test: {meta['test_rows']:,} dòng · Test bắt đầu {meta['test_start']} · Best: {result['best_name']}")
    st.dataframe(metrics,use_container_width=True,hide_index=True)
    if task=="regression":
        fig=px.bar(metrics[metrics.Model.ne("Random Forest (tuned)")],x="Model",y="Test_RMSE",color="Model",title="RMSE trên tập Test – càng thấp càng tốt")
        st.plotly_chart(fig,use_container_width=True)
        gap=metrics[["Model","Train_RMSE","Test_RMSE","Generalization_Gap_RMSE"]].melt("Model",var_name="Tập",value_name="RMSE")
        st.plotly_chart(px.bar(gap,x="Model",y="RMSE",color="Tập",barmode="group",title="Kiểm tra chênh lệch Train/Test"),use_container_width=True)
    else:
        fig=px.bar(metrics,x="Model",y="Test_F1",color="Model",title="F1-score trên tập Test – cân bằng Precision và Recall")
        st.plotly_chart(fig,use_container_width=True)
        st.plotly_chart(px.bar(metrics,x="Model",y=[c for c in ["Test_Precision","Test_Recall","Test_F1"] if c in metrics],barmode="group",title="Precision / Recall / F1 trên tập Test"),use_container_width=True)
    if result["importance"] is not None:
        st.subheader("4. Feature Importance – Random Forest")
        imp=result["importance"].head(18).sort_values("Importance")
        st.plotly_chart(px.bar(imp,x="Importance",y="Feature",orientation="h",title="Mức độ quan trọng của đặc trưng"),use_container_width=True)
        st.caption("Feature importance là mức đóng góp trong mô hình, không chứng minh quan hệ nhân quả. Ticker one-hot có thể xuất hiện trong danh sách.")
    st.subheader("5. Kiểm thử ngoài mẫu – 20 phiên gần nhất")
    pred=result["predictions"].copy(); dates=sorted(pred.Date.unique()); recent=set(dates[-20:]); last20=pred[pred.Date.isin(recent)].copy()
    model_choice=st.selectbox("Mô hình xem chi tiết",sorted(last20.Model.unique()),key=f"pred_model_{task}")
    view=last20[last20.Model.eq(model_choice)].copy()
    if task=="regression":
        view["Sai số tuyệt đối"]=abs(view.Prediction-view.Target_Next_Close)
        st.dataframe(view[["Date","Target_Next_Date","Ticker","Target_Next_Close","Prediction","Sai số tuyệt đối"]].sort_values(["Date","Ticker"]),use_container_width=True,hide_index=True)
        st.metric("MAE trên 20 phiên gần nhất",f"{view['Sai số tuyệt đối'].mean():.4f}")
    else:
        view["Đúng/Sai"]=np.where(view.Prediction.astype(int).eq(view.Target_Direction.astype(int)),"Đúng","Sai")
        st.dataframe(view[["Date","Target_Next_Date","Ticker","Target_Direction","Prediction","Probability_Up","Đúng/Sai"]].sort_values(["Date","Ticker"]),use_container_width=True,hide_index=True)
        st.metric("Accuracy trên 20 phiên gần nhất",f"{(view['Đúng/Sai']=='Đúng').mean():.2%}")
    st.caption("Đây là 20 ngày quan sát cuối trong tập Test có nhãn, không phải khẳng định dữ liệu Vietstock mới nhất. Dòng cuối cùng chưa có phiên kế tiếp sẽ không thể tính sai số.")
    st.subheader("6. Lưu ý diễn giải")
    st.markdown("- Train tốt nhưng Test kém rõ rệt: dấu hiệu overfitting.\n- Cả Train và Test đều kém: có thể underfitting hoặc đặc trưng chưa đủ thông tin.\n- Dự báo giá chịu ảnh hưởng của thang giá từng mã; cần thận trọng khi gộp nhiều cổ phiếu.\n- Kết quả mô hình không phải khuyến nghị mua/bán. Tin tức, cổ tức, chia tách và sự kiện bất thường có thể làm sai lệch dự báo.")
    st.download_button("Tải bảng kết quả CSV",metrics.to_csv(index=False).encode("utf-8-sig"),file_name=f"{task}_metrics.csv",mime="text/csv")

st.divider(); st.subheader("7. Dự báo phiên kế tiếp cho mã được chọn")
model_path=MODEL_DIR/f"{task}_best.joblib"
if model_path.exists():
    from src.models.supervised import predict_new_rows
    tickers=sorted(raw.Ticker.astype(str).unique()); ticker=st.selectbox("Mã cổ phiếu",tickers,key=f"forecast_ticker_{task}")
    if st.button("DỰ BÁO VỚI MÔ HÌNH ĐÃ HUẤN LUYỆN",key=f"forecast_btn_{task}"):
        try:
            forecast=predict_new_rows(raw[raw.Ticker.eq(ticker)],task)
            if forecast.empty: st.warning("Chưa đủ lịch sử để tạo đặc trưng (cần ít nhất 20 phiên hợp lệ).")
            else:
                latest=forecast.sort_values("Date").iloc[-1]
                if task=="regression": st.metric(f"Giá đóng cửa dự báo phiên sau · {ticker}",f"{latest.Prediction:,.2f}")
                else: st.metric(f"Xác suất tăng phiên sau · {ticker}",f"{latest.Probability_Up:.1%}",delta="Tăng" if latest.Probability_Up>=.5 else "Giảm/đi ngang")
                st.caption(f"Dựa trên dữ liệu đến {latest.Date:%d/%m/%Y}. Đây là dự báo mô hình, không phải khuyến nghị đầu tư.")
        except Exception as exc: st.error(str(exc))
else: st.info("Huấn luyện mô hình ở phần trên trước khi dùng chức năng dự báo tự động.")
