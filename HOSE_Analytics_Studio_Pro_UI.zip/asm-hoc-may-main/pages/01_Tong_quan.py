from pathlib import Path
import pandas as pd
import streamlit as st
import plotly.express as px
from src.data.research import PROJECT_ROOT, load_processed
from src.data.universe import RESEARCH_TICKERS
from src.dashboard_ui import render_page_header, render_section_heading, render_empty_panel

render_page_header("HOSE ANALYTICS / OVERVIEW","Phân tích thị trường bằng học máy","Không gian nghiên cứu phân cụm đặc trưng biến động của doanh nghiệp niêm yết trên HOSE.")
st.info("Kết quả hiện là thử nghiệm kỹ thuật có điều kiện. Cơ sở giá Close và Corporate Actions chưa được xác minh độc lập; Cluster ID không phải nhãn rủi ro.")
try:
    df=load_processed()
    df["Date"]=pd.to_datetime(df["Date"],errors="coerce")
    a,b,c,d=st.columns(4)
    a.metric("Doanh nghiệp trong phạm vi",f"{len(RESEARCH_TICKERS)}")
    b.metric("Mã có dữ liệu",f"{df.Ticker.nunique():,}")
    c.metric("Bản ghi Processed",f"{len(df):,}")
    d.metric("Số phiên quan sát",f"{df.Date.nunique():,}")
    left,right=st.columns([1.55,1],gap="large")
    with left:
        render_section_heading("Độ phủ dữ liệu theo mã","Số quan sát thực tế trong file Processed.")
        coverage=df.groupby("Ticker").size().sort_values(ascending=True).rename("Số dòng").reset_index()
        fig=px.bar(coverage,x="Số dòng",y="Ticker",orientation="h",color="Số dòng",color_continuous_scale=["#cfe8e5","#087f83"])
        fig.update_layout(height=620,margin=dict(l=5,r=10,t=20,b=10),coloraxis_showscale=False,paper_bgcolor="white",plot_bgcolor="white")
        st.plotly_chart(fig,use_container_width=True)
    with right:
        render_section_heading("Thông tin nghiên cứu")
        with st.container(border=True):
            st.markdown("**Phạm vi**")
            st.write("43 mã cổ phiếu theo universe cấu hình trong dự án.")
            st.markdown("**Nguồn**")
            st.write("CafeF — cần xác minh price basis và Corporate Actions.")
            st.markdown("**Phương pháp**")
            st.write("K-Means · Agglomerative · DBSCAN")
            st.markdown("**Đơn vị phân tích**")
            st.write("Mỗi doanh nghiệp là một điểm dữ liệu đặc trưng.")
    render_section_heading("Xu hướng dữ liệu gộp","Trung vị Close theo ngày trên các mã có quan sát. Đây không phải chỉ số thị trường.")
    daily=df.groupby("Date",as_index=False)["Close"].median()
    fig=px.line(daily,x="Date",y="Close",labels={"Close":"Trung vị Close","Date":"Ngày"},color_discrete_sequence=["#176b87"])
    fig.update_layout(height=330,margin=dict(l=10,r=10,t=15,b=10),paper_bgcolor="white",plot_bgcolor="white")
    st.plotly_chart(fig,use_container_width=True)
    st.caption(f"Khoảng dữ liệu đọc được: {df.Date.min():%d/%m/%Y} – {df.Date.max():%d/%m/%Y}. Hợp ngày quan sát không thay thế lịch giao dịch HOSE độc lập.")
except (FileNotFoundError,ValueError,OSError) as exc:
    cols=st.columns(4)
    cols[0].metric("Mã trong phạm vi",len(RESEARCH_TICKERS))
    cols[1].metric("Dữ liệu", "Chưa nạp")
    cols[2].metric("Mô hình","03")
    cols[3].metric("Cấu hình","124 dự kiến theo báo cáo")
    render_empty_panel("Chưa có dữ liệu Processed","Tải stock_data_processed.csv tại trang Quản lý dữ liệu. Không có dữ liệu minh họa được tạo tự động.")
st.markdown("#### Danh sách mã nghiên cứu")
st.markdown("".join(f'<span class="ticker">{t}</span>' for t in RESEARCH_TICKERS),unsafe_allow_html=True)
