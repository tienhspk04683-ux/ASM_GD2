from pathlib import Path
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
from src.dashboard_ui import render_page_header,render_empty_panel,render_section_heading
from src.data.research import load_processed
render_page_header("DATA GOVERNANCE / QUALITY CONTROL","Chất lượng dữ liệu","Kiểm tra độ đầy đủ, tính nhất quán và các điểm cần rà soát trước khi diễn giải kết quả.")
try: df=load_processed()
except (FileNotFoundError,ValueError,OSError) as exc:
    render_empty_panel("Chưa đọc được dữ liệu Processed",str(exc));st.stop()
df["Date"]=pd.to_datetime(df.Date,errors="coerce")
numeric=df[["Open","High","Low","Close","Volume"]].apply(pd.to_numeric,errors="coerce")
missing=df.isna().sum().rename("Missing").reset_index().rename(columns={"index":"Trường"})
dup_mask=df.duplicated(["Ticker","Date"],keep=False)
bad_ohlc=((numeric.High<numeric.Open)|(numeric.High<numeric.Close)|(numeric.Low>numeric.Open)|(numeric.Low>numeric.Close)).fillna(False)
neg_volume=(numeric.Volume<0).fillna(False)
a,b,c,d=st.columns(4)
a.metric("Bản ghi",f"{len(df):,}");b.metric("Mã",df.Ticker.nunique());c.metric("Ô thiếu",f"{int(df.isna().sum().sum()):,}");d.metric("Khóa mã-ngày trùng",f"{int(dup_mask.sum()):,}")
render_section_heading("Độ phủ theo mã","Số dòng trong dữ liệu hiện có; không tự kết luận phiên thiếu nếu chưa có lịch giao dịch chuẩn.")
coverage=df.groupby("Ticker").size().sort_values().reset_index(name="Số quan sát")
fig=px.bar(coverage,x="Số quan sát",y="Ticker",orientation="h",color="Số quan sát",color_continuous_scale=["#d9ebe9","#087f83"])
fig.update_layout(height=650,coloraxis_showscale=False,paper_bgcolor="white",plot_bgcolor="white",margin=dict(l=5,r=5,t=15,b=10))
st.plotly_chart(fig,use_container_width=True)
render_section_heading("Tóm tắt kiểm tra")
q=pd.DataFrame([
 {"Kiểm tra":"Missing values","Số lượng":int(df.isna().sum().sum()),"Diễn giải":"Ô thiếu; xem chi tiết theo cột."},
 {"Kiểm tra":"Duplicate Ticker-Date","Số lượng":int(dup_mask.sum()),"Diễn giải":"Các dòng thuộc khóa mã-ngày trùng; cần đối chiếu."},
 {"Kiểm tra":"OHLC range flags","Số lượng":int(bad_ohlc.sum()),"Diễn giải":"Open/Close nằm ngoài High-Low hoặc High/Low không nhất quán."},
 {"Kiểm tra":"Volume âm","Số lượng":int(neg_volume.sum()),"Diễn giải":"Volume âm là bất thường cần kiểm tra."},
])
st.dataframe(q,hide_index=True,use_container_width=True)
left,right=st.columns(2)
with left:
    render_section_heading("Giá trị thiếu theo trường")
    st.dataframe(missing,hide_index=True,use_container_width=True)
with right:
    render_section_heading("Phân phối Volume")
    fig=px.box(df,x="Ticker",y="Volume",points=False,color_discrete_sequence=["#176b87"])
    fig.update_layout(height=360,paper_bgcolor="white",plot_bgcolor="white",xaxis_tickangle=-90)
    st.plotly_chart(fig,use_container_width=True)
if bad_ohlc.any():
    st.warning(f"Phát hiện {int(bad_ohlc.sum())} dòng vi phạm quan hệ OHLC theo phép kiểm tra hiện tại. Giữ nguyên dữ liệu nguồn; không tự động xóa/sửa.")
    cols=[c for c in ["Ticker","Date","Open","High","Low","Close","Data_Quality_Flag","Source_File","Source_Row"] if c in df]
    st.dataframe(df.loc[bad_ohlc,cols],hide_index=True,use_container_width=True)
if dup_mask.any():
    with st.expander("Xem các khóa mã-ngày trùng"):
        st.dataframe(df.loc[dup_mask].sort_values(["Ticker","Date"]),hide_index=True,use_container_width=True)
st.info("Các cờ thống kê không tự động chứng minh dữ liệu sai. Cần xác minh nguồn, price basis, corporate actions, đơn vị Volume và lịch giao dịch trước khi diễn giải mức rủi ro.")
st.download_button("Tải báo cáo kiểm tra nhanh CSV",q.to_csv(index=False).encode("utf-8-sig"),"data_quality_summary.csv","text/csv")
