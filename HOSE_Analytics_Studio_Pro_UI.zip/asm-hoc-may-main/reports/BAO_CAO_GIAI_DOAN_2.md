# BÁO CÁO THỰC NGHIỆM GIAI ĐOẠN 2 — HOSE ANALYTICS

## 1. Dữ liệu và phạm vi

- File Processed hiện có: 53.385 dòng, 43 mã.
- Khoảng ngày ghi trong file: 19/11/2021–18/11/2026.
- Nguồn được nhận diện trong gói dữ liệu và tài liệu dự án: CafeF. Đây **không phải** bằng chứng dữ liệu Vietstock.
- Bài toán dự báo dùng OHLCV theo ngày; target là Close phiên kế tiếp (Regression) và nhãn tăng/không tăng phiên kế tiếp (Classification).
- Chia train/test theo ngày, không shuffle. 20 ngày quan sát cuối được xem riêng bên trong holdout.

## 2. Hồi quy

Baseline Linear Regression so sánh KNN Regressor, Decision Tree Regressor, Random Forest Regressor.

| Mô hình | Train RMSE | Test RMSE | Test MAE | Test R² |
|---|---:|---:|---:|---:|
| Linear Regression | 19.4586 | 30.1254 | 17.0243 | 0.5396 |
| KNN Regressor | 34.4997 | 44.7637 | 31.6900 | -0.0165 |
| Decision Tree | 25.8848 | 40.6057 | 27.3973 | 0.1636 |
| Random Forest | 20.2627 | 33.1298 | 21.6007 | 0.4432 |

Linear Regression có RMSE Test thấp nhất trong lần chạy baseline này. R² của KNN âm, cho thấy cấu hình KNN hiện tại kém hơn baseline dự đoán trung bình trên tập test. Sai số tính theo đơn vị giá của dữ liệu và chịu ảnh hưởng khác biệt thang giá giữa các mã; không so sánh trực tiếp như một tỷ lệ phần trăm.

## 3. Phân loại

Baseline Logistic Regression so sánh KNN, Decision Tree và Random Forest.

| Mô hình | Precision | Recall | F1 | ROC-AUC | Train F1 |
|---|---:|---:|---:|---:|---:|
| Logistic Regression | 0.4342 | 0.4892 | 0.4601 | 0.5369 | 0.5014 |
| KNN Classifier | 0.4268 | 0.4222 | 0.4245 | 0.5219 | 0.4190 |
| Decision Tree | 0.4400 | 0.4714 | 0.4552 | 0.5358 | 0.4678 |
| Random Forest | 0.4384 | 0.5131 | 0.4728 | 0.5450 | 0.5937 |

Random Forest đạt F1 Test cao nhất trong lần chạy baseline, nhưng ROC-AUC chỉ khoảng 0,545; mức phân biệt hai lớp còn yếu. Không được diễn giải đây là mô hình dự báo có độ tin cậy cao.

## 4. Overfitting / Underfitting

- Random Forest phân loại có Train F1 0,5937 và Test F1 0,4728; gap khoảng 0,1209, là dấu hiệu cần theo dõi overfitting.
- KNN được đánh giá Train bằng expanding time-block CV trên một mẫu train có giới hạn, tránh dùng dự báo resubstitution (mỗi điểm là láng giềng của chính nó).
- Linear Regression có gap RMSE 10,6668; vẫn có suy giảm ngoài mẫu.
- Các chỉ số thấp của phân loại cho thấy bài toán khó và/hoặc bộ đặc trưng hiện tại chưa đủ sức dự báo.

## 5. Feature Importance

Random Forest Regressor: Volume_Log là đặc trưng có importance cao nhất trong lần chạy (xấp xỉ 0,3654), kế đến là các biến mã cổ phiếu one-hot. Random Forest Classifier có các đặc trưng đứng đầu là Return_1, Volatility_20, MA5_Ratio và Return_2.

Feature importance phản ánh mức sử dụng đặc trưng trong mô hình, không chứng minh quan hệ nhân quả hay tác động kinh tế độc lập. Cần kiểm tra độ ổn định bằng permutation importance/time-based validation và loại biến định danh nếu mục tiêu là giải thích quan hệ tài chính.

## 6. Tuning và kiểm thử mới

Ứng dụng cung cấp GridSearchCV cho Random Forest với các fold mở rộng theo thời gian và giữ nguyên toàn bộ mã trong cùng ngày ở cùng fold. Chưa có kết quả tuning toàn bộ lịch sử trong báo cáo này; người dùng chạy checkbox tuning trong giao diện để tạo kết quả theo lần chạy thực tế.

20 ngày cuối trong tập Test có nhãn được hiển thị ở giao diện. Đây là holdout của file lịch sử CafeF hiện có, không được gọi là 20 phiên mới trên Vietstock. Để hoàn thành rubric về nguồn, cần xuất 20 phiên từ Vietstock và nạp vào ứng dụng, đồng thời ghi rõ nguồn/timestamp.

## 7. Hạn chế và rủi ro

- Giá Close chưa được xác minh đầy đủ theo corporate actions/điều chỉnh quyền.
- File hiện có là CafeF; rubric yêu cầu Vietstock.
- Không có dữ liệu giao dịch ròng khối ngoại hoặc chỉ số tài chính trong bộ OHLCV; các biến này chưa thể đưa vào mô hình.
- Các dự báo không phản ánh tin tức vĩ mô, thông tin doanh nghiệp, cổ tức, chia tách, thanh khoản thị trường hoặc chi phí giao dịch.
- Không dùng kết quả làm khuyến nghị mua/bán.

## 8. Tái lập

Chạy `streamlit run app.py`, mở mục GIAI ĐOẠN 2. Chọn bài toán, chọn GridSearchCV nếu muốn tuning, bấm HUẤN LUYỆN VÀ ĐÁNH GIÁ. Notebook `notebooks/ASM2_supervised_learning.ipynb` thực hiện cùng quy trình.
