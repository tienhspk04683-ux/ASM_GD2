# HOSE Analytics Studio Pro – UI refresh

## Giao diện
- Masthead navy/teal theo phong cách research studio.
- Thanh điều hướng 7 mục trên một hàng, chia đều chiều rộng.
- Không dùng radio, không dùng icon trên thanh điều hướng.
- Mục đang chọn dùng nút primary nền gradient.
- Responsive: giảm padding/font ở màn hình hẹp.

## Cập nhật trên Windows
1. Dừng Streamlit bằng Ctrl+C.
2. Giải nén ZIP vào thư mục mới.
3. Mở CMD tại thư mục chứa app.py.
4. Kích hoạt môi trường ảo (nếu đã có):
   `.venv\Scripts\activate.bat`
5. Chạy:
   `streamlit run app.py`

Nếu là thư mục mới và chưa có `.venv`:
   `python -m venv .venv`
   `.venv\Scripts\activate.bat`
   `pip install -r requirements.txt`

Mở http://localhost:8501.

## Ghi chú
Đây là bản làm mới giao diện điều hướng và phần khung thương hiệu. Các trang dữ liệu/mô hình vẫn giữ nguyên từ gói ASM2 nguồn. Sau khi chạy trên máy Windows, cần kiểm tra thực tế từng trang và biểu đồ.
