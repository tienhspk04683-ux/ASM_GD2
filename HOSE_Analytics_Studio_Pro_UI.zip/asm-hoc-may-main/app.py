from __future__ import annotations

import runpy
from pathlib import Path

import streamlit as st

from src.dashboard_ui import apply_dashboard_style

st.set_page_config(
    page_title="HOSE Analytics | Research Studio",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="collapsed",
)
apply_dashboard_style()

NAV = {
    "TỔNG QUAN": "pages/01_Tong_quan.py",
    "DỮ LIỆU": "pages/02_Quan_ly_du_lieu.py",
    "CHẤT LƯỢNG": "pages/03_Chat_luong_du_lieu.py",
    "PHÂN TÍCH": "pages/04_Phan_tich_du_lieu.py",
    "PHÂN CỤM": "pages/05_Machine_Learning.py",
    "HỒ SƠ": "pages/06_Du_bao.py",
    "GIAI ĐOẠN 2": "pages/07_Giai_doan_2.py",
}

st.markdown(
    """
    <style>
    :root {
      --ha-ink: #10243a;
      --ha-muted: #64758a;
      --ha-navy: #0b1e33;
      --ha-blue: #173e5c;
      --ha-teal: #19b6a5;
      --ha-line: #dce5ee;
      --ha-bg: #f3f6fa;
    }
    [data-testid="stSidebar"] {display:none !important;}
    [data-testid="stAppViewContainer"] {
      background:
        radial-gradient(ellipse at 88% 0%, rgba(25,182,165,.07), transparent 32%),
        linear-gradient(180deg,#f7f9fc 0%,#f1f5f9 100%);
    }
    [data-testid="stHeader"] {background:rgba(247,249,252,.92);}
    .block-container {
      max-width: 1720px !important;
      padding: 2.1rem 2.2rem 3.5rem !important;
    }

    /* Product masthead */
    .ha-topbar {
      position: relative;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:24px;
      padding:20px 26px;
      margin:0 0 17px 0;
      overflow:hidden;
      border:1px solid rgba(255,255,255,.12);
      border-radius:18px;
      color:#fff;
      background:linear-gradient(112deg,#091b2e 0%,#123653 58%,#0c5964 100%);
      box-shadow:0 14px 34px rgba(9,27,46,.13);
    }
    .ha-topbar:after {
      content:"";
      position:absolute;
      width:270px;height:270px;
      right:-100px;top:-185px;
      border:1px solid rgba(255,255,255,.14);
      border-radius:50%;
      box-shadow:0 0 0 24px rgba(255,255,255,.035),
                 0 0 0 52px rgba(255,255,255,.025);
      pointer-events:none;
    }
    .ha-brand {position:relative;z-index:1;display:flex;flex-direction:column;gap:5px;}
    .ha-brand-name {
      color:#fff;font-size:1.12rem;font-weight:850;
      letter-spacing:.16em;line-height:1.2;
    }
    .ha-brand-sub {
      color:#bfd0df;font-size:.70rem;font-weight:650;
      letter-spacing:.12em;text-transform:uppercase;
    }
    .ha-status {
      position:relative;z-index:1;display:flex;align-items:center;gap:9px;
      color:#d8e7ef;font-size:.69rem;font-weight:750;letter-spacing:.11em;
      white-space:nowrap;
    }
    .ha-status-dot {
      width:8px;height:8px;border-radius:50%;
      background:#31d0b5;box-shadow:0 0 0 4px rgba(49,208,181,.13);
    }

    /* Equal-width, full-row navigation made from native buttons */
    .ha-nav-label {
      margin:0 0 7px 3px;color:#74869a;font-size:.65rem;
      font-weight:850;letter-spacing:.16em;text-transform:uppercase;
    }
    div[data-testid="stHorizontalBlock"]:has(.ha-nav-anchor) {
      gap:8px !important;
    }
    .ha-nav-anchor {display:none;}
    div[data-testid="stHorizontalBlock"]:has(.ha-nav-anchor) .stButton {
      width:100%;
    }
    div[data-testid="stHorizontalBlock"]:has(.ha-nav-anchor) .stButton > button {
      width:100%;min-height:49px;padding:10px 7px;
      border:1px solid #dbe4ed;border-radius:11px;
      background:rgba(255,255,255,.92);color:#28435b;
      font-size:.72rem;font-weight:850;letter-spacing:.035em;
      white-space:nowrap;box-shadow:0 3px 10px rgba(15,39,62,.035);
      transition:all .16s ease;
    }
    div[data-testid="stHorizontalBlock"]:has(.ha-nav-anchor) .stButton > button:hover {
      border-color:#83bcb9;background:#edf7f6;color:#0b7474;
      transform:translateY(-1px);
      box-shadow:0 7px 16px rgba(15,89,96,.08);
    }
    div[data-testid="stHorizontalBlock"]:has(.ha-nav-anchor) .stButton > button[kind="primary"] {
      color:#fff;background:linear-gradient(115deg,#123653,#087e83);
      border:1px solid #087e83;
      box-shadow:0 6px 15px rgba(8,126,131,.2);
    }
    div[data-testid="stHorizontalBlock"]:has(.ha-nav-anchor) .stButton > button p {
      font-weight:850;letter-spacing:.025em;
    }

    /* General component polish */
    h1,h2,h3 {color:#142d45;letter-spacing:-.025em;}
    [data-testid="stMetric"] {
      background:#fff;border:1px solid #e1e8ef;border-radius:15px;
      padding:1rem 1.1rem;box-shadow:0 5px 18px rgba(16,38,63,.045);
    }
    [data-testid="stVerticalBlockBorderWrapper"] {
      border:1px solid #e1e8ef;border-radius:15px;
      box-shadow:0 4px 15px rgba(16,38,63,.035);
    }
    [data-testid="stDataFrame"] {border:1px solid #dfe7ef;border-radius:12px;overflow:hidden;}
    [data-testid="stAlert"] {border-radius:12px;}
    .stButton>button,.stDownloadButton>button {
      border-radius:10px;font-weight:700;min-height:2.6rem;
    }
    .stButton>button[kind="primary"] {
      background:linear-gradient(110deg,#126b78,#0d9488);border-color:#0d9488;
    }

    @media(max-width:1050px) {
      .block-container {padding:1.3rem 1.1rem 2.5rem !important;}
      .ha-topbar {padding:17px 19px;}
      .ha-status {display:none;}
      div[data-testid="stHorizontalBlock"]:has(.ha-nav-anchor) {gap:5px !important;}
      div[data-testid="stHorizontalBlock"]:has(.ha-nav-anchor) .stButton > button {
        font-size:.64rem;padding:8px 3px;white-space:normal;line-height:1.15;
      }
    }
    @media(max-width:650px) {
      .block-container {padding:1rem .65rem 2rem !important;}
      .ha-brand-name {font-size:.96rem;}
      .ha-brand-sub {font-size:.58rem;}
    }
    </style>
    <header class="ha-topbar">
      <div class="ha-brand">
        <div class="ha-brand-name">HOSE ANALYTICS</div>
        <div class="ha-brand-sub">Equity Research &nbsp;·&nbsp; Machine Learning Studio</div>
      </div>
      <div class="ha-status"><span class="ha-status-dot"></span> RESEARCH WORKSPACE &nbsp; / &nbsp; ASM 2</div>
    </header>
    <div class="ha-nav-label">WORKSPACE NAVIGATION</div>
    """,
    unsafe_allow_html=True,
)

if "hose_nav" not in st.session_state or st.session_state.hose_nav not in NAV:
    st.session_state.hose_nav = "TỔNG QUAN"

# Each item receives exactly the same column width. Active state is styled
# with Streamlit's primary button; no radio controls or icon glyphs are used.
cols = st.columns(len(NAV), gap="small")
for (label, _page), col in zip(NAV.items(), cols):
    with col:
        st.markdown('<span class="ha-nav-anchor"></span>', unsafe_allow_html=True)
        is_active = st.session_state.hose_nav == label
        if st.button(
            label,
            key=f"ha_nav_{label}",
            type="primary" if is_active else "secondary",
            use_container_width=True,
        ):
            if st.session_state.hose_nav != label:
                st.session_state.hose_nav = label
                st.rerun()

st.markdown("<div style='height:18px'></div>", unsafe_allow_html=True)
runpy.run_path(
    str(Path(__file__).parent / NAV[st.session_state.hose_nav]),
    run_name="__main__",
)
