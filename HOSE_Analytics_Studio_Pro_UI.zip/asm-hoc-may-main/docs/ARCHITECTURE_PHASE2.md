# HOSE Analytics Premium — Kiến trúc Giai đoạn 2

## Phạm vi
- Giai đoạn 1: K-Means, Agglomerative, DBSCAN; đặc trưng rủi ro có điều kiện; PCA 2D và bản đồ doanh nghiệp.
- Giai đoạn 2A (Regression): dự báo `Close` phiên kế tiếp; Linear Regression baseline, KNN Regressor, Decision Tree Regressor, Random Forest Regressor. Metrics: MAE, RMSE, R².
- Giai đoạn 2B (Classification): dự báo hướng phiên kế tiếp (`1` nếu return > 0, ngược lại `0`); Logistic Regression baseline, KNN, Decision Tree, Random Forest. Metrics: Precision, Recall, F1, ROC-AUC.

## Chống rò rỉ dữ liệu
- Tạo lag/rolling features theo từng Ticker sau khi sắp xếp thời gian.
- Target lấy Close phiên kế tiếp trong cùng mã.
- Train/Test tách theo ngày, không shuffle.
- Tuning dùng expanding folds theo khối ngày; các mã cùng ngày không bị chia sang hai fold.
- Scaler, imputer và OneHotEncoder nằm trong Pipeline, chỉ fit trên tập train.
- 20 ngày quan sát cuối trong Test được báo cáo riêng; phiên cuối cùng không có target tương lai không được chấm điểm.

## Tự động thêm dữ liệu
- Upload CSV/XLSX yêu cầu Date, Ticker, Open, High, Low, Close, Volume.
- File bổ sung được lưu tại `data/staging/additional_stock_data.csv`; không ghi đè file Processed gốc.
- Hợp nhất theo khóa Ticker-Date, tạo lại features và dự đoán bằng model đã lưu.
- Unknown ticker được OneHotEncoder xử lý bằng `handle_unknown=ignore`; dự báo chỉ nên dùng nếu mã mới có đủ lịch sử để tạo rolling features.
- Nạp dữ liệu không tự huấn luyện lại. Nút huấn luyện lại là hành động riêng, giúp giữ tính ổn định của model hiện hành.

## Artifact
- `artifacts/supervised/regression_best.joblib`
- `artifacts/supervised/classification_best.joblib`
- `*_metrics.csv`, `*_predictions.csv`, `*_feature_importance.csv`, `*_metadata.json`

## Giới hạn nguồn
Dữ liệu đã đóng gói trong dự án có tên file và tài liệu nguồn CafeF. Không được mô tả là Vietstock. Để hoàn thành yêu cầu 20 phiên Vietstock, cần nạp tệp Vietstock được cấp phép/đã xuất từ tài khoản người dùng và lưu provenance của tệp. Giá Close và corporate actions cần xác minh trước diễn giải tài chính.

## Diễn giải
- Feature importance là mức đóng góp dự báo, không chứng minh nhân quả.
- Cluster ID là nhãn kỹ thuật, không tự động là rủi ro thấp/trung bình/cao.
- Mô hình không phải khuyến nghị mua/bán.
