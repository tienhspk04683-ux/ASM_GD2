# HOSE Analytics — Premium UI Upgrade

## Nội dung nâng cấp
- Thiết kế dashboard premium: navy, teal, nền sáng, thẻ KPI và hero header thống nhất.
- Trang Tổng quan: KPI theo dữ liệu thực tế, độ phủ theo mã, chuỗi trung vị Close theo ngày.
- Trang Phân tích: biểu đồ Close/Volume tương tác, histogram + boxplot Return, heatmap tương quan, bảng đặc trưng có điều kiện.
- Trang Chất lượng dữ liệu: độ phủ từng mã, missing, duplicate, cờ OHLC, Volume và tải CSV tóm tắt.
- Trang Phân cụm: giữ nguyên pipeline K-Means/Agglomerative/DBSCAN; bổ sung biểu đồ so sánh cấu hình.
- Trang Hồ sơ doanh nghiệp: quy mô cụm, hồ sơ đặc trưng, PCA 2D có nhãn mã và tra cứu doanh nghiệp.
- Plotly được thêm để tăng khả năng tương tác.

## Chạy trên Windows
Mở PowerShell hoặc CMD tại thư mục có `app.py`:

```powershell
python -m venv .venv
```

Nếu dùng PowerShell và bị chặn Activate.ps1, chuyển sang CMD:
```powershell
cmd
```
```cmd
.venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m compileall -q app.py src pages tests scripts
python -m unittest discover -s tests -v
streamlit run app.py
```

Mở `http://localhost:8501`.

## Dữ liệu cần có
ZIP gốc được cung cấp không chứa dữ liệu Processed thực tế (chỉ có `.gitkeep` trong `data/processed/` và `data/raw/`). Để xem đầy đủ dashboard và chạy phân cụm, cần có file:
`data/processed/stock_data_processed.csv`

File cần có các cột:
`Date, Ticker, Open, High, Low, Close, Volume`
Các cột phụ như `Data_Quality_Flag`, `Source_File`, `Source_Row` được dùng nếu có.

Có thể nạp file qua trang **Quản lý dữ liệu**. Hãy dùng dữ liệu bạn có quyền sử dụng. Không đưa thông tin đăng nhập/API key vào repository.

## Quan trọng về diễn giải
- Dữ liệu trong dự án được ghi nguồn CafeF; price basis và Corporate Actions chưa được xác minh độc lập.
- Không diễn giải Cluster ID thành mức rủi ro thấp/trung bình/cao.
- Không tự động xóa hoặc nội suy ngày thiếu, không sửa Raw/Processed.
- Chỉ số Silhouette/DB/CH là chỉ số nội bộ, không có nhãn chuẩn và không tự chứng minh giá trị kinh tế.
- Biểu đồ dashboard lấy từ CSV thực tế; nếu chưa có dữ liệu, ứng dụng hiển thị trạng thái trống thay vì tạo số liệu giả.

## Kiểm tra kỹ thuật
Đã chạy:
- `python -m compileall -q app.py src pages tests scripts`: thành công.
- `python -m unittest discover -s tests -v`: 34/34 tests đạt trong môi trường kiểm tra này.

Các kiểm thử là unit tests với fixture; chưa xác nhận dữ liệu thị trường thực tế hoặc kiểm thử tương tác trên máy Windows của bạn.
