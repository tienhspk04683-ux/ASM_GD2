import unittest
import pandas as pd
import numpy as np
from src.models.supervised import make_supervised_frame, NUMERIC

class SupervisedFeatureTests(unittest.TestCase):
    def test_next_session_target_is_shifted_within_ticker(self):
        dates=pd.bdate_range('2024-01-01',periods=45)
        rows=[]
        for ticker,base in [('AAA',20),('BBB',50)]:
            for i,date in enumerate(dates):
                close=base+i*.1
                rows.append({'Date':date,'Ticker':ticker,'Open':close,'High':close+1,'Low':close-1,'Close':close,'Volume':1000+i})
        frame=make_supervised_frame(pd.DataFrame(rows))
        aaa=frame[frame.Ticker.eq('AAA')].sort_values('Date')
        self.assertAlmostEqual(aaa.iloc[0].Target_Next_Close, aaa.iloc[0].Close+.1)
        self.assertTrue((frame.Target_Next_Date>frame.Date).all())
        self.assertTrue(set(NUMERIC).issubset(frame.columns))

    def test_latest_unlabeled_row_can_be_featured_for_forecast(self):
        dates=pd.bdate_range('2024-01-01',periods=45)
        rows=[]
        for i,date in enumerate(dates):
            close=20+i*.1
            rows.append({'Date':date,'Ticker':'AAA','Open':close,'High':close+1,'Low':close-1,'Close':close,'Volume':1000+i})
        frame=make_supervised_frame(pd.DataFrame(rows),require_target=False)
        self.assertEqual(frame.Date.max(),dates[-1])
        self.assertTrue(frame[NUMERIC].notna().all().all())

if __name__=='__main__': unittest.main()
