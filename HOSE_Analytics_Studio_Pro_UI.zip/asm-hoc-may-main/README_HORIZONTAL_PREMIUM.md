# HOSE Analytics — Premium Horizontal Navigation

## Bản cập nhật
- Chuyển điều hướng Streamlit từ sidebar sang thanh menu ngang phía trên (position="top").
- Giữ 6 công cụ: Tổng quan, Quản lý dữ liệu, Chất lượng dữ liệu, Phân tích dữ liệu, Phân cụm mô hình, Hồ sơ doanh nghiệp.
- Đã tích hợp dữ liệu người dùng gửi từ `DU_LIEU_CHUNG_KHOAN.zip`.
- Đã tạo `data/processed/stock_data_processed.csv` theo schema Date, Ticker, Open, High, Low, Close, Volume, Adjusted_Close, Data_Quality_Flag.
- Đã chạy pipeline tạo 43 bộ đặc trưng và 124 cấu hình phân cụm; lưu artifacts để trang Hồ sơ doanh nghiệp có thể đọc.
- Giữ file ZIP nguồn gốc trong `data/raw/DU_LIEU_CHUNG_KHOAN_original.zip`.

## Kiểm kê dữ liệu
- 215 workbook XLSX = 43 mã × 5 giai đoạn.
- 53.471 dòng thô.
- Có 86 dòng trùng khóa Ticker + Date; các bản ghi trùng thống nhất OHLCV.
- Đã giữ một bản ghi cho mỗi khóa, còn 53.385 dòng.
- Khoảng ngày quan sát: 19/11/2021 đến 18/11/2026.
- Có 16 dòng được gắn cờ bất thường OHLC; không tự động sửa.
- Có 43 mã; số quan sát theo mã không hoàn toàn bằng nhau.

## Chạy trên Windows (CMD)
Mở CMD tại thư mục có `app.py`, chạy:
```cmd
python -m venv .venv
.venv\\Scripts\\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```
Mở http://localhost:8501

Nếu đã có `.venv`, chỉ cần kích hoạt rồi cài requirements và chạy Streamlit.

## Lưu ý học thuật
- Nguồn dữ liệu trong workbook là CafeF, không phải Vietstock.
- Các đặc trưng Return/Volatility/Drawdown dùng giá Close chưa xác minh đầy đủ cơ sở điều chỉnh và Corporate Actions.
- Nhãn Cluster là nhãn kỹ thuật, không tự động tương đương mức rủi ro thấp/cao.
- Kết quả phân cụm là phân tích khám phá có điều kiện, không phải khuyến nghị đầu tư.
- `Data_Quality_Flag` ghi nhận các bất thường; dữ liệu gốc không bị chỉnh sửa.
