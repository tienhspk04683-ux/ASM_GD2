# Staging area for user-supplied additions

Upload CSV/XLSX via the Phase 2 page. The app writes `additional_stock_data.csv` here and merges it by Ticker-Date at read time. The original `data/processed/stock_data_processed.csv` is not overwritten. Do not commit confidential/licensed files unless permitted.
